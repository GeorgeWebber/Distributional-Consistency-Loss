# Models package

The code in this package is attributable to the Deep Image Prior GitHub page (https://github.com/DmitryUlyanov/deep-image-prior), reproduced under Apache License 2.0.